# This script contains all the following system operators :
#   - 
#

import bpy

from .SPT_functions import * 

# TODO :
#   - Batch import : système qui récupère tous les fichiers blend d'un dossier et ajoute leur contenu à l'asset browser de Blender + possibilité d'import instantané (https://shaterstudio.gumroad.com/l/ohzllx)
#   - Export avec preset, export en plusieurs formats d'un coup
#   - Scene validator : ajouter de quoi régler les problèmes (opérateurs intégrés qui clean), test avec des empty, image..., show hidden ou del hidden pour les modifiers
#   - Render tool : auto-render de frame ranges, changements de paramètres entre deux...
#   - Comparator : Comparaison de 2 versions pour review les changements

# ─────────────────────────────────────────────

#  OPERATORS

# ─────────────────────────────────────────────
    
class SPT_OT_clean_scene(bpy.types.Operator):
    
    bl_idname = "spt.clean_scene"
    bl_label  = "Clean scene"
    bl_description = "Purges all unused data"
    bl_options = {"UNDO"}
        
    def execute(self, context):
        props = context.scene.spt
        active_obj = context.object

        bpy.data.orphans_purge()
    
        self.report({"INFO"}, "Scene cleaned")
        return {"FINISHED"}

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_show_info_popup(bpy.types.Operator):
    bl_idname = "spt.show_info_popup"
    bl_label = "Info"

    title: bpy.props.StringProperty(default="Information")
    icon: bpy.props.StringProperty(default="INFO")
    footer: bpy.props.StringProperty(default="Note...")

    # A line for each message/icon, joined by "\n"
    messages: bpy.props.StringProperty(default="")
    icons: bpy.props.StringProperty(default="")
    operators: bpy.props.StringProperty(default="")

    def invoke(self, context, event):
        self.width = 630
        self.char = 6

        window = context.window
        center_x = (window.width//2)-(self.width//2)
        center_y = (window.height//2)+(self.width//2)
        window.cursor_warp(center_x, center_y)
        return context.window_manager.invoke_popup(self, width=self.width)

    def draw(self, context):
        layout = self.layout
        draw_wrapped_label(layout, context, self.title, icon=self.icon, width=self.width, char_size=self.char)
        layout.separator()

        message_lines = self.messages.split("\n") if self.messages else []
        icon_lines = self.icons.split("\n") if self.icons else []
        op_lines = self.operators.split("\n") if self.operators else []

        for i, message in enumerate(message_lines):
            line_icon = icon_lines[i] if i < len(icon_lines) else "NONE"
            row = layout.row()
            box = row.box()
            if line_icon == "X":
                box.alert = True
            draw_wrapped_label(box, context, message, icon=line_icon, width=self.width, char_size=self.char)
            if op_lines[i] != "" :
                row.operator(op_lines[i])
        
        layout.separator()
        draw_wrapped_label(layout, context, self.footer, width=self.width, char_size=self.char)

    def execute(self, context):
        return {'FINISHED'}

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_scene_validator(bpy.types.Operator):
    
    bl_idname = "spt.scene_validator"
    bl_label  = "Scene validator"
    bl_description = "Shows all typical mistakes in your scene to make sure it is ready to be delivered"
    
    @classmethod
    def poll(cls, context):
        return context.scene.objects

    def execute(self, context):
        props = context.scene.spt

        self.validation_check = []
        for i in range(9) :
            self.validation_check.append(1)

        self.uv_less_objects = []
        self.loc_full_objects = []
        self.scale_full_objects = []
        self.rot_full_objects = []
        self.normals_objects = []
        self.name_less_objects = []
        self.smooth_less_objects = []
        self.modifier_hidden_objects = []

        for obj in context.scene.objects:
            if obj.type == "MESH" and obj.visible_get() and not obj.data.uv_layers:
                self.validation_check[0] = 0
                self.uv_less_objects.append(obj.name)
            
            if not obj.location == Vector((0.0,0.0,0.0)):
                self.validation_check[1] = 0
                self.loc_full_objects.append(obj.name)
            
            if not obj.scale == Vector((1.0,1.0,1.0)):
                self.validation_check[2] = 0
                self.scale_full_objects.append(obj.name)

            rot = (obj.rotation_euler[0], obj.rotation_euler[1], obj.rotation_euler[2])
            if not rot == (0.0, 0.0, 0.0):
                self.validation_check[3] = 0
                self.rot_full_objects.append(obj.name)
            
            if not check_normals_outward(obj):
                self.validation_check[4] = 0
                self.normals_objects.append(obj.name)
            
            if not check_name(obj):
                self.validation_check[5] = 0
                self.name_less_objects.append(obj.name)

            smoothed = False
            for mod in obj.modifiers:
                if mod.type == 'NODES' and mod.node_group is not None:
                    if mod.node_group.name.startswith("Smooth by Angle"):
                        smoothed = True
            if not smoothed :
                self.validation_check[6] = 0
                self.smooth_less_objects.append(obj.name)

            hidden = False
            for mod in obj.modifiers:
                if not mod.show_viewport:
                    hidden = True
            if hidden :
                self.validation_check[7] = 0
                self.modifier_hidden_objects.append(obj.name)

            if count_total_verts(context) >= 100000 :
                self.validation_check[8] = 0

        self.display_result(context)

        return {"FINISHED"}

    def display_result(self, context):
        props = context.scene.spt

        icons_check = []
        for i in range(len(self.validation_check)) :
            icon = "CHECKMARK" if self.validation_check[i] == 1 else "X"
            icons_check.append(icon)

        op_check = []
        if self.validation_check[0] == 0 :
            uv_text = f"UVs missing on following objects : {self.uv_less_objects}"
            op_check.append("spt.uv_creation")
        else:
            uv_text = f"UVs done"
            op_check.append("")

        if self.validation_check[1] == 0 :
            loc_text = f"Location not applied to following objects : {self.loc_full_objects}"
            op_check.append("spt.apply_location")
        else:
            loc_text = f"Locations applied"
            op_check.append("")

        if self.validation_check[2] == 0 :
            scale_text = f"Scale not applied to following objects : {self.scale_full_objects}"
            op_check.append("spt.apply_scale")
        else:
            scale_text = f"Scales applied"
            op_check.append("")

        if self.validation_check[3] == 0 :
            rot_text = f"Rotation not applied to following objects : {self.rot_full_objects}"
            op_check.append("spt.apply_rot")
        else:
            rot_text = f"Rotations applied"
            op_check.append("")

        if self.validation_check[4] == 0 :
            normals_text = f"Normals are (partly) inward in following objects : {self.normals_objects}"
            op_check.append("spt.normals_orient")
        else:
            normals_text = f"Normals outward"
            op_check.append("")

        if self.validation_check[5] == 0 :
            naming_text = f"Naming seems to be off for the following objects (numbering, unaccepted characters...) : {self.name_less_objects}"
            op_check.append("spt.fix_name")
        else:
            naming_text = f"Naming is correct"
            op_check.append("")

        if self.validation_check[6] == 0 :
            smooth_text = f"Smooth not applied on the following objects : {self.smooth_less_objects}"
            op_check.append("spt.apply_smooth")
        else:
            smooth_text = f"Smooth applied"
            op_check.append("")
        
        if self.validation_check[7] == 0 :
            modifier_text = f"Modifiers are (partly) hidden on the following objects : {self.modifier_hidden_objects}, make sure it is normal"
            op_check.append("spt.show_modifier")
        else:
            modifier_text = f"Modifiers clean"
            op_check.append("")

        if self.validation_check[8] == 0 :
            polycount_text = f"Points count exceeds 100 000, try reducing it as much as possible"
            op_check.append("")
        else:
            polycount_text = f"Points count is correct"
            op_check.append("")
        
        if 0 in self.validation_check :
            info_footer = "Some objects do not meet validation requirements to be delivered, please correct them before continuing" 
            props.scene_validated = False
        else:
            info_footer = "Your scene seems clean and validated, you may deliver it"
            props.scene_validated = True

        bpy.ops.spt.show_info_popup(
            'INVOKE_DEFAULT',
            title="Scene validation",
            icon='INFO_LARGE',
            messages="\n".join([uv_text, loc_text, scale_text, rot_text, normals_text, naming_text, smooth_text, modifier_text, polycount_text]),
            icons="\n".join(icons_check),
            operators="\n".join(op_check),
            footer=info_footer,
        )

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_uv_creation(bpy.types.Operator):
    
    bl_idname = "spt.uv_creation"
    bl_label  = "Fix UVs"
    bl_description = "Fixes UVs by applying smart projection to UV-less objects"

    def execute(self, context):
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action='DESELECT')

        for obj in context.scene.objects:
            if obj.type == "MESH" and obj.visible_get() and not obj.data.uv_layers:
                obj.select_set(True)
                context.view_layer.objects.active = obj

                bpy.ops.object.mode_set(mode="EDIT")
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.uv.smart_project()

                bpy.ops.object.mode_set(mode="OBJECT")
                obj.select_set(False)
        
        return {'FINISHED'}

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_apply_location(bpy.types.Operator):
    
    bl_idname = "spt.apply_location"
    bl_label  = "Fix locations"
    bl_description = "Fixes rotations by applying location to problematic objects"

    def execute(self, context):
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action='DESELECT')

        for obj in context.scene.objects:
            if not obj.location == Vector((0.0,0.0,0.0)):
                obj.select_set(True)
                context.view_layer.objects.active = obj
                
                bpy.ops.object.transform_apply(location=True, rotation=False, scale=False)

                obj.select_set(False)

                bpy.ops.spt.scene_validator()
        
        return {'FINISHED'}

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_apply_scale(bpy.types.Operator):
    
    bl_idname = "spt.apply_scale"
    bl_label  = "Fix scales"
    bl_description = "Fixes rotations by applying scale to problematic objects"

    def execute(self, context):
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action='DESELECT')

        for obj in context.scene.objects:
            if not obj.scale == Vector((1.0,1.0,1.0)):
                obj.select_set(True)
                context.view_layer.objects.active = obj
                
                bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

                obj.select_set(False)
        
        return {'FINISHED'}

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_apply_rot(bpy.types.Operator):
    
    bl_idname = "spt.apply_rot"
    bl_label  = "Fix rotations"
    bl_description = "Fixes rotations by applying rotation to problematic objects"

    def execute(self, context):
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action='DESELECT')

        for obj in context.scene.objects:
            rot = (obj.rotation_euler[0], obj.rotation_euler[1], obj.rotation_euler[2])
            if not rot == (0.0, 0.0, 0.0):
                obj.select_set(True)
                context.view_layer.objects.active = obj
                
                bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)

                obj.select_set(False)
        
        return {'FINISHED'}

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_normals_orient(bpy.types.Operator):
    
    bl_idname = "spt.normals_orient"
    bl_label  = "Fix normals"
    bl_description = "Fixes normals by recalculating them on problematic objects"

    def execute(self, context):
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action='DESELECT')

        for obj in context.scene.objects:
            if not check_normals_outward(obj):
                mesh = obj.data
                obj.select_set(True)
                context.view_layer.objects.active = obj

                bpy.ops.object.mode_set(mode="EDIT")
                bm = bmesh.from_edit_mesh(mesh)
                bm.faces.ensure_lookup_table()

                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.normals_make_consistent(inside=False)

                bm = bmesh.from_edit_mesh(mesh)
                bm.faces.ensure_lookup_table()

                bpy.ops.object.mode_set(mode="OBJECT")
                obj.select_set(False)
        
        return {'FINISHED'}

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_fix_name(bpy.types.Operator):
    
    bl_idname = "spt.fix_name"
    bl_label  = "Fix names"
    bl_description = "Fixes names by correcting them on problematic objects"

    def execute(self, context):
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action='DESELECT')

        for obj in context.scene.objects:
            if not check_name(obj):
                new_name = obj.name

                unaccepted_char = ["&", "é", "#", "è", "à", "@", "ç", "ù", "*", "{", "}", "(", ")", "[", "]", "€", "$", "~"]
                for i, char in enumerate(new_name):
                    if char in unaccepted_char :
                        new_name = f"{new_name[:i]}{new_name[i+1:]}"
                
                if len(new_name) > 4 and new_name[-4] == "." and new_name[-3:].isdigit():
                    new_name = new_name[:-4]
                    unique = False
                    i = 0
                    while not unique :
                        # Setting new_name, then checking if it is unique or increment
                        curr_name = f"{new_name}{fmt_index(i)}"
                        curr_obj = context.scene.objects.get(curr_name)

                        if not curr_obj :
                            base_obj = context.scene.objects.get(new_name)
                            if base_obj and base_obj != obj :
                                base_obj.name = f"{new_name}_00"
                                new_name = f"{new_name}{fmt_index(i+1)}"
                            elif i != 0 :
                                new_name = curr_name
                            unique = True
                        elif curr_obj == obj :
                            unique = True
                        i+=1

                for i, char in enumerate(new_name):
                    if char == " " :
                        new_name = f"{new_name[:i]}_{new_name[i+1:]}"

                obj.name=new_name
                    
                
        
        return {'FINISHED'}

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_apply_smooth(bpy.types.Operator):
    
    bl_idname = "spt.apply_smooth"
    bl_label  = "Fix smooth"
    bl_description = "Fixes smooth by applying auto-smooth to problematic objects"

    def execute(self, context):
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action='DESELECT')

        for obj in context.scene.objects:
            smoothed = False
            for mod in obj.modifiers:
                if mod.type == 'NODES' and mod.node_group is not None:
                    if mod.node_group.name.startswith("Smooth by Angle"):
                        smoothed = True
            if not smoothed :
                obj.select_set(True)
                context.view_layer.objects.active = obj
                
                bpy.ops.object.shade_auto_smooth()

                obj.select_set(False)
        
        return {'FINISHED'}

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_show_modifier(bpy.types.Operator):
    
    bl_idname = "spt.show_modifier"
    bl_label  = "Fix modifiers"
    bl_description = "Fixes modifiers by showing hidden ones on problematic objects"

    def execute(self, context):
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action='DESELECT')

        for obj in context.scene.objects:
            hidden = False
            for mod in obj.modifiers:
                if not mod.show_viewport:
                    mod.show_viewport = True
        
        return {'FINISHED'}

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_export_tool(bpy.types.Operator):
    
    bl_idname = "spt.export_tool"
    bl_label  = "Export tool"
    bl_description = "Allows you to export multiple files from your scene using presets and/or multiple format"
    
    @classmethod
    def poll(cls, context):
        return context.scene.objects and context.scene.spt.scene_validated

    def execute(self, context):
        props = context.scene.spt

