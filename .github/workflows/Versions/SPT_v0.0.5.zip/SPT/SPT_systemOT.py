# This script contains all the following system operators :
#   - 
#

import bpy

from .SPT_functions import * 

# TODO :
#   - Batch import : système qui récupère tous les fichiers blend d'un dossier et ajoute leur contenu à l'asset browser de Blender + possibilité d'import instantané (https://shaterstudio.gumroad.com/l/ohzllx)
#   - Export avec preset, export en plusieurs formats d'un coup
#   - Scene validator : show hidden ou del hidden pour les modifiers
#   - Render tool : auto-render de frame ranges, changements de paramètres entre deux...
#   - Comparator : Comparaison de 2 versions pour review les changements

# ─────────────────────────────────────────────

#  OPERATORS

# ─────────────────────────────────────────────
    
class SPT_OT_clean_scene(bpy.types.Operator):
    
    bl_idname = "spt.clean_scene"
    bl_label  = "Clean scene"
    bl_description = "Purges all unused data"
    bl_options = {"UNDO"}
        
    def execute(self, context):
        props = context.scene.spt
        active_obj = context.object

        bpy.data.orphans_purge()
    
        self.report({"INFO"}, "Scene cleaned")
        return {"FINISHED"}

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_fix_obj_name(bpy.types.Operator):
    
    bl_idname = "spt.fix_obj_name"
    bl_label  = "Fix object name"
    bl_description = "Fixes current object's name"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return context.object and not check_name(context.object)

    def execute(self, context):
        obj = context.object
        fix_obj_name(context, obj)
        
        return {'FINISHED'}

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_show_info_popup(bpy.types.Operator):
    bl_idname = "spt.show_info_popup"
    bl_label = "Info"

    title: bpy.props.StringProperty(default="Information")
    icon: bpy.props.StringProperty(default="INFO")
    footer: bpy.props.StringProperty(default="Note...")

    # A line for each message/icon, joined by "\n"
    messages: bpy.props.StringProperty(default="")
    icons: bpy.props.StringProperty(default="")
    operators: bpy.props.StringProperty(default="")

    def invoke(self, context, event):
        self.width = 630
        self.char = 6

        window = context.window
        center_x = (window.width//2)-(self.width//2)
        center_y = (window.height//2)+(self.width//2)
        window.cursor_warp(center_x, center_y)
        return context.window_manager.invoke_popup(self, width=self.width)

    def draw(self, context):
        layout = self.layout
        draw_wrapped_label(layout, context, self.title, icon=self.icon, width=self.width, char_size=self.char)
        layout.separator()

        message_lines = self.messages.split("\n") if self.messages else []
        icon_lines = self.icons.split("\n") if self.icons else []
        op_lines = self.operators.split("\n") if self.operators else []

        for i, message in enumerate(message_lines):
            line_icon = icon_lines[i] if i < len(icon_lines) else "NONE"
            row = layout.row()
            box = row.box()
            if line_icon == "X":
                box.alert = True
            draw_wrapped_label(box, context, message, icon=line_icon, width=self.width, char_size=self.char)
            if op_lines[i] != "" :
                box = row.box()
                box.operator(op_lines[i])
        
        layout.separator()
        draw_wrapped_label(layout, context, self.footer, width=self.width, char_size=self.char)

    def execute(self, context):
        return {'FINISHED'}

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_uv_creation(bpy.types.Operator):
    
    bl_idname = "spt.uv_creation"
    bl_label  = "Fix UVs"
    bl_description = "Fixes UVs by applying smart projection to UV-less objects"
    bl_options = {"UNDO"}

    def execute(self, context):
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action='DESELECT')

        for obj in context.scene.objects:
            if obj.type == "MESH" and obj.visible_get() and not obj.data.uv_layers:
                obj.select_set(True)
                context.view_layer.objects.active = obj

                bpy.ops.object.mode_set(mode="EDIT")
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.uv.smart_project()

                bpy.ops.object.mode_set(mode="OBJECT")
                obj.select_set(False)
        
        return {'FINISHED'}

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_apply_location(bpy.types.Operator):
    
    bl_idname = "spt.apply_location"
    bl_label  = "Fix locations"
    bl_description = "Fixes rotations by applying location to problematic objects"
    bl_options = {"UNDO"}

    def execute(self, context):
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action='DESELECT')

        for obj in context.scene.objects:
            if obj.type in ["MESH", "ARMATURE"] and not obj.location == Vector((0.0,0.0,0.0)):
                obj.select_set(True)
                context.view_layer.objects.active = obj
                
                bpy.ops.object.transform_apply(location=True, rotation=False, scale=False)

                obj.select_set(False)
        
        return {'FINISHED'}

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_apply_scale(bpy.types.Operator):
    
    bl_idname = "spt.apply_scale"
    bl_label  = "Fix scales"
    bl_description = "Fixes rotations by applying scale to problematic objects"
    bl_options = {"UNDO"}

    def execute(self, context):
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action='DESELECT')

        for obj in context.scene.objects:
            if not obj.scale == Vector((1.0,1.0,1.0)):
                obj.select_set(True)
                context.view_layer.objects.active = obj
                
                bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

                obj.select_set(False)
        
        return {'FINISHED'}

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_apply_rot(bpy.types.Operator):
    
    bl_idname = "spt.apply_rot"
    bl_label  = "Fix rotations"
    bl_description = "Fixes rotations by applying rotation to problematic objects"
    bl_options = {"UNDO"}

    def execute(self, context):
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action='DESELECT')

        for obj in context.scene.objects:
            rot = (obj.rotation_euler[0], obj.rotation_euler[1], obj.rotation_euler[2])
            if not rot == (0.0, 0.0, 0.0):
                obj.select_set(True)
                context.view_layer.objects.active = obj
                
                bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)

                obj.select_set(False)
        
        return {'FINISHED'}

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_normals_orient(bpy.types.Operator):
    
    bl_idname = "spt.normals_orient"
    bl_label  = "Fix normals"
    bl_description = "Fixes normals by recalculating them on problematic objects"
    bl_options = {"UNDO"}

    def execute(self, context):
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action='DESELECT')

        for obj in context.scene.objects:
            if obj.type == "MESH" and obj.visible_get() and not check_normals_outward(obj):
                mesh = obj.data
                obj.select_set(True)
                context.view_layer.objects.active = obj

                bpy.ops.object.mode_set(mode="EDIT")
                bm = bmesh.from_edit_mesh(mesh)
                bm.faces.ensure_lookup_table()

                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.normals_make_consistent(inside=False)

                bm = bmesh.from_edit_mesh(mesh)
                bm.faces.ensure_lookup_table()

                bpy.ops.object.mode_set(mode="OBJECT")
                obj.select_set(False)
        
        return {'FINISHED'}

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_fix_name(bpy.types.Operator):
    
    bl_idname = "spt.fix_name"
    bl_label  = "Fix names"
    bl_description = "Fixes names by correcting them on problematic objects"
    bl_options = {"UNDO"}

    def execute(self, context):
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action='DESELECT')

        for obj in context.scene.objects:
            if not check_name(obj):
                fix_obj_name(context, obj)
        
        return {'FINISHED'}

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_apply_smooth(bpy.types.Operator):
    
    bl_idname = "spt.apply_smooth"
    bl_label  = "Fix smooth"
    bl_description = "Fixes smooth by applying auto-smooth to problematic objects"
    bl_options = {"UNDO"}

    def execute(self, context):
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action='DESELECT')

        for obj in context.scene.objects:
            if obj.type == "MESH":
                smoothed = False
                for mod in obj.modifiers:
                    if mod.type == 'NODES' and mod.node_group is not None:
                        if mod.node_group.name.startswith("Smooth by Angle"):
                            smoothed = True
                if not smoothed :
                    obj.select_set(True)
                    context.view_layer.objects.active = obj
                    
                    bpy.ops.object.shade_auto_smooth()

                    obj.select_set(False)
        
        return {'FINISHED'}

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_show_modifier(bpy.types.Operator):
    
    bl_idname = "spt.show_modifier"
    bl_label  = "Fix modifiers"
    bl_description = "Fixes modifiers by showing hidden ones on problematic objects"
    bl_options = {"UNDO"}

    def execute(self, context):
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action='DESELECT')

        for obj in context.scene.objects:
            hidden = False
            for mod in obj.modifiers:
                if not mod.show_viewport:
                    mod.show_viewport = True
        
        return {'FINISHED'}

# ──────────────────────────────────────────────────────────────────────────────────────────
class SPT_OT_export_tool(bpy.types.Operator):
    
    bl_idname = "spt.export_tool"
    bl_label  = "Export tool"
    bl_description = "Allows you to export multiple files from your scene using presets and/or multiple format"
    
    @classmethod
    def poll(cls, context):
        return context.scene.objects

    def execute(self, context):
        props = context.scene.spt

