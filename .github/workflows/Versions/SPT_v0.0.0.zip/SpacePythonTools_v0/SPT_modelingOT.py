# This script contains all the following modeling operators :
#   - Selection :
#       - Selecting all faces touching active one(s), can loop to take all the surface
#

import bpy
import bmesh
import sys
import os

# ─────────────────────────────────────────────

#  FUNCTIONS

# ─────────────────────────────────────────────

from .SPT_functions import * 

# ─────────────────────────────────────────────

#  OPERATORS

# ─────────────────────────────────────────────
    
class SPT_OT_select_touching_faces(bpy.types.Operator):
    
    bl_idname = "spt.select_touching_faces"
    bl_label  = "Select touching faces"
    bl_description = ""
    bl_options = {"UNDO"}
    
    dont_show_again: bpy.props.BoolProperty(
        name="Don't show again",
        default=False,
    )
    
    def invoke(self, context, event): # ─────────────────────────────────────────────
        props = context.scene.spt
        
        if props.loop_selection and not self.dont_show_again:
            # Opens a verification pop-up 
            return context.window_manager.invoke_props_dialog(self)
        else:
            # No verification pop-up
            return self.execute(context)
        
    def draw(self, context): # ─────────────────────────────────────────────
        props = context.scene.spt
        layout = self.layout
        
        # Pop-up content
        layout.label(text="Warning : this operation can take time. Continue ?")
        layout.label(text="You may want to save your project before continuing.")
        
        layout.separator()
        
        row = layout.row()
        row.operator("wm.save_mainfile", text="Save project", icon='FILE_TICK')
        row.prop(self, "dont_show_again")
        
        layout.separator()
        
    def execute(self, context): # ─────────────────────────────────────────────
        props = context.scene.spt
        active_obj, bm = get_bmesh_from_active_object()
                
        # Location table -> vertices list, built once only since locations always stay the same during loop
        pos_to_verts = {}
        for v in bm.verts :
            key = (round(v.co.x, 5), round(v.co.y, 5), round(v.co.z, 5))
            pos_to_verts.setdefault(key, []).append(v)
        
        keep_search = True
        while keep_search :
            # Getting selected vertices and preparing lists
            verts_sel = [v for v in bm.verts if v.select]
            touching_faces = {}
            touching_verts = []
            
            # Getting vertices touching selected ones
            for v_sel in verts_sel :
                key = (round(v_sel.co.x, 5), round(v_sel.co.y, 5), round(v_sel.co.z, 5))
                for v in pos_to_verts.get(key, ()) :
                    if v != v_sel :
                        touching_verts.append(v)
            
            # Getting faces created by touching vertices, counting how many vertices are on the same faces
            for v in touching_verts :
                for face in v.link_faces :
                    if not face in touching_faces.keys() :
                        touching_faces[face] = 0
                    else :
                        touching_faces[face] += 1
            
            if props.select_connected :
                for v in verts_sel :
                    for face in v.link_faces :
                        if not face in touching_faces.keys() :
                            touching_faces[face] = 0
                        else :
                            touching_faces[face] += 1
            
            # Keeping only faces with multiple touching points if diagonal selection is disabled
            i = 0
            minimal_value = 0 if props.select_diagonal else 1
            for f, value in touching_faces.items() :
                if value >= minimal_value and f.select == False :
                    f.select = True
                    i+=1
            
            # Updating bmesh and stopping search if no new faces were found
            bmesh.update_edit_mesh(active_obj.data)
            keep_search = True if i != 0 and props.loop_selection else False
    
        return {"FINISHED"}
        
        